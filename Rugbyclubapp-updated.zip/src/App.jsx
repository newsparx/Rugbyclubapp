import React from 'react';
import SignInPortal from './components/SignInPortal';

function App() {
  return (
    <div>
      <SignInPortal />
    </div>
  );
}

export default App;
